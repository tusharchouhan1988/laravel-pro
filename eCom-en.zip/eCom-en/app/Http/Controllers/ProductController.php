<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\Cart;
use App\Models\Order;

use Session;
use Illuminate\Support\Facades\DB;
class ProductController extends Controller
{
    //
    function index()
    {
        $data= Product::all();
        $startprice = Product::groupBy('price')->orderby('price', 'ASC')->get();
        $endprice = Product::groupBy('price')->orderby('price', 'ASC')->get();
        $category = Product::groupBy('category')->orderby('category', 'ASC')->get();
        return view('product',['products'=>$data,'startprice'=>$startprice,'endprice'=>$endprice,'category'=>$category]);
    }
    function detail($id)
    {
        $data =Product::find($id);
        return view('detail',['product'=>$data]);
    }
    function search(Request $req)
    {
        $query = '';
        $query.='SELECT * FROM products WHERE ';
        if(!empty($req->category))
        {
            $query.='`category` LIKE "%'.$req->category.'%"';  
        }
        if(!empty($req->category) && !empty($req->start_price) && !empty($req->start_price))
        {
            $query.=' AND ';  
        }
        if(!empty($req->start_price) && !empty($req->end_price))
        {
            $query.=' (products.price >= '.$req->start_price.' AND products.price <= '.$req->end_price.')';  
        }
        $results = DB::select( DB::raw($query) );
        $html='';
        if(!empty($results) && count($results))
        {
            foreach ($results as $key => $pro) {
                $html.='<a href="detail/'.$pro->id.'">';
                $html.='<div class="col-md-3">';
                $html.='<div class="card" style="min-height: 200px;max-height: 205px;">';
                $html.='<img src="'.$pro->gallery.'" alt="Avatar" style="min-height: 160px;max-height: 160px;">';
                $html.='<div class="container">';
                $html.='<h4><b>'.$pro->name.'</b></h4>';
                $html.='</div>';
                $html.='</div>';
                $html.='</div>';
                $html.='</a>';
            }
        }
        return $html;
    }
    function addToCart(Request $req)
    {
        if($req->session()->has('user'))
        {
           $cart= new Cart;
           $cart->user_id=$req->session()->get('user')['id'];
           $cart->product_id=$req->product_id;
           $cart->save();
           return redirect('/');

        }
        else
        {
            return redirect('/login');
        }
    }
    static function cartItem()
    {
     $userId=Session::get('user')['id'];
     return Cart::where('user_id',$userId)->count();
    }
    function cartList()
    {
        $userId=Session::get('user')['id'];
       $products= DB::table('cart')
        ->join('products','cart.product_id','=','products.id')
        ->where('cart.user_id',$userId)
        ->select('products.*','cart.id as cart_id')
        ->get();

        return view('cartlist',['products'=>$products]);
    }
    function removeCart($id)
    {
        Cart::destroy($id);
        return redirect('cartlist');
    }
    function orderNow()
    {
        $userId=Session::get('user')['id'];
        $total= $products= DB::table('cart')
         ->join('products','cart.product_id','=','products.id')
         ->where('cart.user_id',$userId)
         ->sum('products.price');
 
         return view('ordernow',['total'=>$total]);
    }
    function orderPlace(Request $req)
    {
        $userId=Session::get('user')['id'];
         $allCart= Cart::where('user_id',$userId)->get();
         foreach($allCart as $cart)
         {
             $order= new Order;
             $order->product_id=$cart['product_id'];
             $order->user_id=$cart['user_id'];
             $order->status="pending";
             $order->payment_method=$req->payment;
             $order->payment_status="pending";
             $order->address=$req->address;
             $order->save();
             Cart::where('user_id',$userId)->delete(); 
         }
         $req->input();
         return redirect('/');
    }
    function myOrders()
    {
        $userId=Session::get('user')['id'];
        $orders= DB::table('orders')
         ->join('products','orders.product_id','=','products.id')
         ->where('orders.user_id',$userId)
         ->get();
 
         return view('myorders',['orders'=>$orders]);
    }
}
