<?php $__env->startSection("content"); ?>
<div class="custom-product">
    <div id="myCarousel" class="carousel slide" data-ride="carousel">
        <!-- Indicators -->
        <ol class="carousel-indicators">
          <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
          <li data-target="#myCarousel" data-slide-to="1"></li>
          <li data-target="#myCarousel" data-slide-to="2"></li>
        </ol>
      
        <!-- Wrapper for slides -->
        <div class="carousel-inner">
          <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="item <?php echo e($item['id']==1?'active':''); ?>">
        <a href="detail/<?php echo e($item['id']); ?>">
              <img class="slider-img" src="<?php echo e($item['gallery']); ?>">
            <div class="carousel-caption slider-text">
              <h3><?php echo e($item['name']); ?></h3>
              <p><?php echo e($item['description']); ?></p>
            </div>
            </a>
          </div>
    
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      
        <!-- Left and right controls -->
        <a class="left carousel-control" href="#myCarousel" data-slide="prev">
          <span class="glyphicon glyphicon-chevron-left"></span>
          <span class="sr-only">Previous</span>
        </a>
        <a class="right carousel-control" href="#myCarousel" data-slide="next">
          <span class="glyphicon glyphicon-chevron-right"></span>
          <span class="sr-only">Next</span>
        </a>
      </div>
      <div class="row" style="margin-top: 55px;margin-bottom: 55px;">
        <div class="container">
          <h3>Filter Products</h3>
          <div class="row">
            <form action="/search" class="navbar-form navbar-left">
            <div class="col-md-4">
              <select class="form-control search-box" style="width: 100% !important;" id="start_price" aria-label="Default select example">
                <option value="">select start price</option>
                <?php $__currentLoopData = $startprice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($price->price); ?>"><?php echo e($price->price); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
            <div class="col-md-4">
              <select class="form-control search-box"  style="width: 100% !important;"  id="end_price" aria-label="Default select example">
                <option value="">select end price</option>
                <?php $__currentLoopData = $endprice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($price->price); ?>"><?php echo e($price->price); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
            <div class="col-md-4">
              <select class="form-control search-box"  style="width: 100% !important;"  id="category" aria-label="Default select example">
                <option value="">select Category</option>
                <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($category->category); ?>"><?php echo e($category->category); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
            <div class="col-md-12">
              <button type="button" onclick="findproduct();" class="btn btn-default">Search</button>
            </div>
          </form>
        </div>
        </div>
      </div>
      <div class="trending-wrapper">
        <h3>Tredning Products</h3>
        


        <div class="row">
          <div class="col-md-12" id="searchresult">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="detail/<?php echo e($item['id']); ?>">
            <div class="col-md-3">
              <div class="card" style="min-height: 200px;max-height: 205px;">
                <img src="<?php echo e($item['gallery']); ?>" alt="Avatar" style="min-height: 160px;max-height: 160px;">
                <div class="container">
                  <h4><b><?php echo e($item['name']); ?></b></h4> 
                </div>
              </div>
            </div>
            </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>

      </div>
      </div>
</div>
<?php $__env->stopSection(); ?>

<script>
  function findproduct()
  {
    var start_price = $('#start_price option:selected').val();
    var end_price = $('#end_price option:selected').val();
    var category = $('#category option:selected').val();
    if((start_price != '' && end_price != '') || category != '')
    {
      $.ajax({
        url: "<?php echo e(url('/search')); ?>",
        type: "POST",
        data: {"_token": "<?php echo e(csrf_token()); ?>",'start_price' : start_price,'end_price' : end_price,'category' : category},
        dataType: "html",
        success: function(data){
          console.log(data);
          $("#searchresult").html(data);
        }
      });
    }
    else
    {
      alert('please provide proper data for search');
    }

  }
</script>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\eCom-en-laravel-master\resources\views/product.blade.php ENDPATH**/ ?>